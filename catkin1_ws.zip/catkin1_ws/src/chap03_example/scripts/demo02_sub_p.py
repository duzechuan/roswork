#! /sur/bin/env python
 
import rospy
from std_msgs.msg import String  #发布的消息类型
"""
    使用python实现消息订阅：
    1.导包
    2.初始化ROS节点
    3.创建订阅者对象
    4.编写回调函数处理数据
    5.spin()
"""
def doMsg(msg):
    rospy.loginfo("我订阅的数据：%s",msg.data)
 
if __name__=="__main__":
 
    #2.初始化ROS节点
    rospy.init_node("dingyuezhe02")
    #3.创建订阅者对象
    sub = rospy.Subscriber("huati02",String,doMsg,queue_size=10)
    #4.编写回调函数处理数据
    #5.spin()
    rospy.spin()