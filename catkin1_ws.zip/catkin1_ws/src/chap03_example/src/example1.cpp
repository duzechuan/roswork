#include <ros/ros.h>
int main(int argc, char **argv)
{
  ros::init(argc, argv, "hello_ros");
  ros::NodeHandle nh;
  ROS_INFO("Hello ROS!");
  return 0;
  }